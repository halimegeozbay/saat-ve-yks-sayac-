using System;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Threading;
using System.Xml;

[assembly: AssemblyTitle("YKS Masa Saati")]
[assembly: AssemblyDescription("Windows için saat ve YKS geri sayımı")]
[assembly: AssemblyVersion("1.0.0.0")]

public sealed class ExamCountdown
{
    public static readonly DateTimeOffset Tyt = new DateTimeOffset(2027, 6, 19, 10, 15, 0, TimeSpan.FromHours(3));
    public static readonly DateTimeOffset Ayt = new DateTimeOffset(2027, 6, 20, 10, 15, 0, TimeSpan.FromHours(3));
    public readonly DateTimeOffset Target;
    public readonly string Session;
    public readonly long Seconds;

    public ExamCountdown(DateTimeOffset now, int mode)
    {
        bool ayt = mode == 2 || (mode == 0 && now >= Tyt);
        Target = ayt ? Ayt : Tyt;
        Session = ayt ? "AYT" : "TYT";
        Seconds = Math.Max(0, (long)Math.Ceiling((Target - now).TotalSeconds));
    }
}

public sealed class ClockWindow : Window
{
    private readonly CultureInfo Turkish = CultureInfo.GetCultureInfo("tr-TR");
    private readonly TextBlock date, clock, seconds, title, days, hours, minutes, examDate;
    private readonly Grid countdown;
    private readonly ComboBox session;
    private readonly CheckBox showSeconds;
    private readonly Button fullscreenButton;
    private readonly DispatcherTimer timer;
    private bool fullscreen;
    private Rect previousBounds;
    private WindowState previousState;
    private readonly string settingsPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "YksMasaSaati", "settings.xml");

    public ClockWindow()
    {
        Title = "YKS 2027 · Masa Saati";
        Width = 1100;
        Height = 720;
        MinWidth = 500;
        MinHeight = 400;
        WindowStartupLocation = WindowStartupLocation.CenterScreen;
        var content = (Grid)XamlReader.Parse(Layout);
        Content = content;
        date = (TextBlock)content.FindName("Today");
        clock = (TextBlock)content.FindName("Clock");
        seconds = (TextBlock)content.FindName("Seconds");
        title = (TextBlock)content.FindName("ExamTitle");
        days = (TextBlock)content.FindName("Days");
        hours = (TextBlock)content.FindName("Hours");
        minutes = (TextBlock)content.FindName("Minutes");
        examDate = (TextBlock)content.FindName("ExamDate");
        countdown = (Grid)content.FindName("Countdown");
        session = (ComboBox)content.FindName("Session");
        showSeconds = (CheckBox)content.FindName("ShowSeconds");
        fullscreenButton = (Button)content.FindName("Fullscreen");
        LoadSettings();
        session.SelectionChanged += delegate { UpdateClock(); SaveSettings(); };
        showSeconds.Click += delegate { UpdateClock(); SaveSettings(); };
        fullscreenButton.Click += delegate { ToggleFullscreen(); };
        PreviewKeyDown += HandleKey;
        timer = new DispatcherTimer(DispatcherPriority.Background);
        timer.Interval = TimeSpan.FromSeconds(1);
        timer.Tick += delegate { UpdateClock(); };
        StateChanged += delegate
        {
            if (WindowState == WindowState.Minimized) timer.Stop();
            else { UpdateClock(); timer.Start(); }
        };
        Closed += delegate { timer.Stop(); };
        UpdateClock();
        timer.Start();
    }

    private void UpdateClock()
    {
        DateTime now = DateTime.Now;
        clock.Text = now.ToString("HH:mm", Turkish);
        date.Text = now.ToString("d MMMM yyyy dddd", Turkish).ToUpper(Turkish);
        seconds.Text = now.ToString("ss", Turkish);
        seconds.Visibility = showSeconds.IsChecked == true ? Visibility.Visible : Visibility.Hidden;
        ExamCountdown exam = new ExamCountdown(DateTimeOffset.UtcNow, session.SelectedIndex);
        title.Text = "YKS 2027 · " + exam.Session;
        countdown.Visibility = exam.Seconds > 0 ? Visibility.Visible : Visibility.Collapsed;
        days.Text = (exam.Seconds / 86400).ToString(Turkish);
        hours.Text = (exam.Seconds / 3600 % 24).ToString("00", Turkish);
        minutes.Text = (exam.Seconds / 60 % 60).ToString("00", Turkish);
        examDate.Text = exam.Seconds > 0 ? exam.Target.ToString("d MMMM yyyy · HH:mm", Turkish) : "Sınav saati geçti.";
    }

    private void HandleKey(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.F11 || (e.Key == Key.Escape && fullscreen))
        {
            ToggleFullscreen();
            e.Handled = true;
        }
    }

    private void ToggleFullscreen()
    {
        if (!fullscreen)
        {
            previousState = WindowState;
            previousBounds = WindowState == WindowState.Normal ? new Rect(Left, Top, Width, Height) : RestoreBounds;
            WindowState = WindowState.Normal;
            WindowStyle = WindowStyle.None;
            ResizeMode = ResizeMode.NoResize;
            WindowState = WindowState.Maximized;
            fullscreenButton.Content = "Tam ekrandan çık · Esc";
        }
        else
        {
            WindowState = WindowState.Normal;
            WindowStyle = WindowStyle.SingleBorderWindow;
            ResizeMode = ResizeMode.CanResize;
            Left = previousBounds.Left;
            Top = previousBounds.Top;
            Width = previousBounds.Width;
            Height = previousBounds.Height;
            WindowState = previousState;
            fullscreenButton.Content = "Tam ekran · F11";
        }
        fullscreen = !fullscreen;
    }

    private void LoadSettings()
    {
        session.SelectedIndex = 0;
        showSeconds.IsChecked = true;
        try
        {
            if (!File.Exists(settingsPath)) return;
            var document = new XmlDocument();
            document.XmlResolver = null;
            document.Load(settingsPath);
            if (document.DocumentElement == null) return;
            int mode;
            bool enabled;
            if (int.TryParse(document.DocumentElement.GetAttribute("session"), out mode) && mode >= 0 && mode <= 2) session.SelectedIndex = mode;
            if (bool.TryParse(document.DocumentElement.GetAttribute("seconds"), out enabled)) showSeconds.IsChecked = enabled;
        }
        catch (IOException) { }
        catch (UnauthorizedAccessException) { }
        catch (XmlException) { }
    }

    private void SaveSettings()
    {
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(settingsPath));
            var document = new XmlDocument();
            XmlElement element = document.CreateElement("settings");
            element.SetAttribute("session", session.SelectedIndex.ToString(CultureInfo.InvariantCulture));
            element.SetAttribute("seconds", (showSeconds.IsChecked == true).ToString());
            document.AppendChild(element);
            string temporary = settingsPath + "." + Guid.NewGuid().ToString("N") + ".tmp";
            try
            {
                document.Save(temporary);
                if (File.Exists(settingsPath)) File.Replace(temporary, settingsPath, null);
                else File.Move(temporary, settingsPath);
            }
            finally { if (File.Exists(temporary)) File.Delete(temporary); }
        }
        catch (IOException) { }
        catch (UnauthorizedAccessException) { }
    }

    private const string Layout = @"
<Grid xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation'
      xmlns:x='http://schemas.microsoft.com/winfx/2006/xaml' TextElement.Foreground='#F2F6FF' TextElement.FontFamily='Segoe UI'>
  <Grid.Background>
    <LinearGradientBrush StartPoint='0,0' EndPoint='1,1'>
      <GradientStop Color='#14253E' Offset='0'/>
      <GradientStop Color='#090E1C' Offset='.45'/>
      <GradientStop Color='#304F71' Offset='1'/>
    </LinearGradientBrush>
  </Grid.Background>
  <Grid.Resources>
    <Style TargetType='Button'>
      <Setter Property='Foreground' Value='#DCE8FC'/>
      <Setter Property='Background' Value='#142035'/>
      <Setter Property='BorderBrush' Value='#364760'/>
      <Setter Property='Padding' Value='16,8'/>
      <Setter Property='FontSize' Value='13'/>
      <Setter Property='MinHeight' Value='36'/>
      <Setter Property='Template'>
        <Setter.Value>
          <ControlTemplate TargetType='Button'>
            <Border x:Name='Surface' Background='{TemplateBinding Background}' BorderBrush='{TemplateBinding BorderBrush}' BorderThickness='1' CornerRadius='6' Padding='{TemplateBinding Padding}'>
              <ContentPresenter HorizontalAlignment='Center' VerticalAlignment='Center'/>
            </Border>
            <ControlTemplate.Triggers>
              <Trigger Property='IsMouseOver' Value='True'><Setter TargetName='Surface' Property='Background' Value='#263953'/></Trigger>
              <Trigger Property='IsKeyboardFocused' Value='True'><Setter TargetName='Surface' Property='BorderBrush' Value='#A9CCFB'/></Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>
  </Grid.Resources>
  <Grid.RowDefinitions><RowDefinition/><RowDefinition Height='Auto'/></Grid.RowDefinitions>
  <Viewbox Margin='50,35,50,20' Stretch='Uniform'>
    <StackPanel Width='650' Margin='30'>
      <TextBlock x:Name='Today' Foreground='#A9B5CE' FontSize='16' FontWeight='SemiBold' TextAlignment='Center' Margin='0,0,0,4'/>
      <Grid HorizontalAlignment='Center'>
        <TextBlock x:Name='Clock' FontSize='174' FontWeight='Light' TextAlignment='Center'/>
        <TextBlock x:Name='Seconds' Foreground='#A9B5CE' FontSize='30' HorizontalAlignment='Right' VerticalAlignment='Bottom' Margin='0,0,-48,40'/>
      </Grid>
      <Border Width='355' BorderBrush='#354155' BorderThickness='0,1,0,0' Padding='0,25,0,0' Margin='0,3,0,0'>
        <StackPanel>
          <TextBlock x:Name='ExamTitle' FontSize='16' FontWeight='SemiBold' Foreground='#A9CCFB' TextAlignment='Center'/>
          <Grid x:Name='Countdown' Margin='0,16,0,16'>
            <Grid.ColumnDefinitions><ColumnDefinition/><ColumnDefinition/><ColumnDefinition/></Grid.ColumnDefinitions>
            <StackPanel><TextBlock x:Name='Days' FontSize='47' FontWeight='Light' TextAlignment='Center'/><TextBlock Text='GÜN' FontSize='11' Foreground='#A9B5CE' TextAlignment='Center'/></StackPanel>
            <Border Grid.Column='1' BorderBrush='#354155' BorderThickness='1,0,0,0'><StackPanel><TextBlock x:Name='Hours' FontSize='47' FontWeight='Light' TextAlignment='Center'/><TextBlock Text='SAAT' FontSize='11' Foreground='#A9B5CE' TextAlignment='Center'/></StackPanel></Border>
            <Border Grid.Column='2' BorderBrush='#354155' BorderThickness='1,0,0,0'><StackPanel><TextBlock x:Name='Minutes' FontSize='47' FontWeight='Light' TextAlignment='Center'/><TextBlock Text='DAKİKA' FontSize='11' Foreground='#A9B5CE' TextAlignment='Center'/></StackPanel></Border>
          </Grid>
          <TextBlock x:Name='ExamDate' FontSize='14' Foreground='#A9B5CE' TextAlignment='Center'/>
        </StackPanel>
      </Border>
    </StackPanel>
  </Viewbox>
  <StackPanel Grid.Row='1' Orientation='Horizontal' HorizontalAlignment='Center' Margin='12,0,12,22'>
    <ComboBox x:Name='Session' Width='145' VerticalContentAlignment='Center' Margin='0,0,17,0' AutomationProperties.Name='YKS oturumu' FontSize='13'>
      <ComboBoxItem>Sıradaki oturum</ComboBoxItem><ComboBoxItem>TYT</ComboBoxItem><ComboBoxItem>AYT</ComboBoxItem>
    </ComboBox>
    <CheckBox x:Name='ShowSeconds' Content='Saniye' Foreground='#DCE8FC' VerticalAlignment='Center' VerticalContentAlignment='Center' Margin='0,0,17,0'/>
    <Button x:Name='Fullscreen' Content='Tam ekran · F11'/>
  </StackPanel>
</Grid>";
}

internal static class Program
{
    [DllImport("user32.dll")]
    private static extern bool SetProcessDPIAware();

    [STAThread]
    private static void Main()
    {
        SetProcessDPIAware();
        var application = new Application();
        application.Run(new ClockWindow());
    }
}
