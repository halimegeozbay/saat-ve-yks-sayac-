$ErrorActionPreference = 'Stop'
$framework = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319'
$wpf = Join-Path $framework 'WPF'
$destination = Join-Path $PSScriptRoot 'release'
New-Item -ItemType Directory -Force -Path $destination | Out-Null
& (Join-Path $framework 'csc.exe') /nologo /target:winexe /platform:anycpu /optimize+ "/out:$destination\YKS-Masa-Saati.exe" "/win32manifest:$PSScriptRoot\app.manifest" "/reference:$wpf\PresentationFramework.dll" "/reference:$wpf\PresentationCore.dll" "/reference:$wpf\WindowsBase.dll" /reference:System.Xaml.dll "$PSScriptRoot\YksSaat.cs"
if ($LASTEXITCODE -ne 0) { throw 'Derleme başarısız.' }
